package com.example.sms.dto.system;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * Query Scaffold 생성 요청 (QuerySpec).
 * rawQuery 안의 $변수는 검색조건 규약이다. 예: AND A.SEND_DT >= $start_dt
 */
public class ScaffoldRequestDTO {

    @NotBlank(message = "moduleName은 필수입니다.")
    @Pattern(regexp = "^[a-z][a-z0-9]*$", message = "moduleName은 영문 소문자와 숫자만 사용할 수 있습니다.")
    private String moduleName;

    @NotBlank(message = "domainId는 필수입니다.")
    @Pattern(regexp = "^[a-z][a-z0-9-]*$", message = "domainId는 영문 소문자, 숫자, 하이픈만 사용할 수 있습니다.")
    private String domainId;

    @NotBlank(message = "domainClass는 필수입니다.")
    @Pattern(regexp = "^[A-Z][A-Za-z0-9]*$", message = "domainClass는 영문 대문자로 시작하는 Java 클래스명이어야 합니다.")
    private String domainClass;

    @NotBlank(message = "domainName은 필수입니다.")
    private String domainName;

    @NotBlank(message = "rawQuery는 필수입니다.")
    private String rawQuery;

    @NotBlank(message = "orderBy는 필수입니다. 결정적 정렬 컬럼을 입력하세요.")
    private String orderBy;

    private boolean includeCreateUpdate;
    private boolean includeExcel;
    private boolean includePrivacy;

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getDomainClass() {
        return domainClass;
    }

    public void setDomainClass(String domainClass) {
        this.domainClass = domainClass;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getRawQuery() {
        return rawQuery;
    }

    public void setRawQuery(String rawQuery) {
        this.rawQuery = rawQuery;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public boolean isIncludeCreateUpdate() {
        return includeCreateUpdate;
    }

    public void setIncludeCreateUpdate(boolean includeCreateUpdate) {
        this.includeCreateUpdate = includeCreateUpdate;
    }

    public boolean isIncludeExcel() {
        return includeExcel;
    }

    public void setIncludeExcel(boolean includeExcel) {
        this.includeExcel = includeExcel;
    }

    public boolean isIncludePrivacy() {
        return includePrivacy;
    }

    public void setIncludePrivacy(boolean includePrivacy) {
        this.includePrivacy = includePrivacy;
    }
}
